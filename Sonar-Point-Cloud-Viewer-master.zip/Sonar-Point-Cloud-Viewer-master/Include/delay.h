#ifndef DELAY_H
#define DELAY_H
#include <stdint.h>

extern void Delay(uint32_t dlyTicks);
extern void ShortDelay(uint32_t dlyTicks);
#endif
