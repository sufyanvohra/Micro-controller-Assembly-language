#include<stdio.h>

int main()
{
system("python uart.py");
return 0;
}

